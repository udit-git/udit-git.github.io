Pricing Tables
=========

Simple responsive pricing tables, in 3 different styles and with a bouncy animation while switching to different plans.

[Article on CodyHouse](http://codyhouse.co/gem/pricing-tables/)

[Demo](http://codyhouse.co/demo/pricing-tables/index.html)
 
[Terms](http://codyhouse.co/terms/)
